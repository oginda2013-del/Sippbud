# SIPBUDDY — Nairobi MVP starter

A mobile-first Expo / React Native prototype for an adult social meetup app.

## Included in this prototype
- Discover sample nearby profiles
- Send demo meetup invitations
- Offer a drink (demo-only; no payment is taken)
- Browse sample public-venue meetups and request to join
- Draft a meetup
- Profile bio and 18+ self-confirmation UI
- Safety guidance and five-tab navigation

## Run locally
1. Install Node.js (LTS) and Expo Go on an Android phone.
2. Extract this folder and open a terminal in it.
3. Run `npm install`.
4. Run `npx expo start`.
5. Scan the QR code with Expo Go.

For Android emulator use `npm run android`. For iOS use `npm run ios` on a Mac with Xcode.

## Important prototype limitations
This is a front-end prototype with sample profiles and meetups. It does not yet have accounts, live GPS, real chat, identity/age verification, moderation tooling, venue inventory, payments, or a production database. The buttons clearly use demo alerts and do not charge money or publish real meetups.

## Recommended production architecture
- Expo / React Native app for Android and iOS
- Supabase Auth + PostgreSQL + Row Level Security for accounts and data
- Server-side location search with user-controlled approximate radius
- Realtime messaging with reporting, blocking, rate limits and moderation
- Payment provider integration only after legal/compliance review and explicit checkout
- Venue onboarding and verified venue listings
- Admin dashboard, audit logs, incident response and privacy controls

## Safety requirements before public launch
- Enforce 18+ access with a reliable age-assurance provider; a checkbox alone is not verification.
- Default to public venues; never expose precise live location to other users.
- Make drink offers optional and non-coercive; do not incentivize alcohol consumption.
- Support alcohol-free meetups, report/block, emergency contact sharing and moderation escalation.
- Publish privacy policy, terms, community standards and clear payment/refund rules.
- Review Kenyan data protection, consumer, payments, alcohol advertising and licensing requirements with qualified local counsel.
